package com.gary.todolist;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModel;

import com.gary.todolist.database.AppDatabase;
import com.gary.todolist.database.TaskEntry;

public class AddTaskViewModel extends ViewModel {
    private LiveData<TaskEntry> task;

    public AddTaskViewModel (AppDatabase database, int taskId){
        task = database.taskDao().loadTaskById(taskId);
    }

    public LiveData<TaskEntry> getTasks(){ return task; }
}
